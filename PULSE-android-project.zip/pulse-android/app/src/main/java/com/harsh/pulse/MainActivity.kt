package com.harsh.pulse

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.view.View
import android.webkit.*
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var wakeLock: PowerManager.WakeLock
    private lateinit var audioManager: AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PulseMusic::WakeLock")
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        val root = FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            layoutParams = FrameLayout.LayoutParams(-1, -1)
        }

        val splash = buildSplash()
        webView = buildWebView()
        webView.visibility = View.INVISIBLE

        root.addView(webView)
        root.addView(splash)
        setContentView(root)

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                webView.evaluateJavascript("window.__PULSE_ANDROID__=true;", null)
                splash.animate().alpha(0f).setDuration(500).withEndAction {
                    splash.visibility = View.GONE
                    webView.visibility = View.VISIBLE
                }.start()
            }
            override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {}
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(msg: ConsoleMessage?) = true
            override fun onPermissionRequest(request: PermissionRequest?) { request?.grant(request.resources) }
            override fun onJsAlert(view: WebView?, url: String?, msg: String?, result: JsResult?): Boolean { result?.confirm(); return true }
            override fun onJsConfirm(view: WebView?, url: String?, msg: String?, result: JsConfirmResult?): Boolean { result?.confirm(); return true }
            override fun onJsPrompt(view: WebView?, url: String?, msg: String?, default_: String?, result: JsPromptResult?): Boolean { result?.confirm(default_); return true }
        }

        webView.addJavascriptInterface(Bridge(), "PulseAndroid")
        webView.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack()
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildWebView() = WebView(this).apply {
        layoutParams = FrameLayout.LayoutParams(-1, -1)
        setLayerType(View.LAYER_TYPE_HARDWARE, null)
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            @Suppress("DEPRECATION") allowFileAccessFromFileURLs = true
            @Suppress("DEPRECATION") allowUniversalAccessFromFileURLs = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            userAgentString = "PulseMusic/1.0 Android"
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun requestAudioFocus(): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setOnAudioFocusChangeListener { change ->
                        val js = when(change) {
                            AudioManager.AUDIOFOCUS_LOSS, AudioManager.AUDIOFOCUS_LOSS_TRANSIENT ->
                                "try{window.player.audio.pause()}catch(e){}"
                            else -> ""
                        }
                        if (js.isNotEmpty()) webView.post { webView.evaluateJavascript(js, null) }
                    }.build()
                audioFocusRequest = req
                audioManager.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            } else {
                @Suppress("DEPRECATION")
                audioManager.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN) ==
                        AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            }
        }

        @JavascriptInterface
        fun keepAwake(on: Boolean) = runOnUiThread {
            if (on && !wakeLock.isHeld) wakeLock.acquire(10*60*1000L)
            else if (!on && wakeLock.isHeld) wakeLock.release()
        }

        @JavascriptInterface
        fun showToast(msg: String) = runOnUiThread {
            android.widget.Toast.makeText(this@MainActivity, msg, android.widget.Toast.LENGTH_SHORT).show()
        }

        @JavascriptInterface
        fun getInfo() = """{"platform":"android","sdk":${Build.VERSION.SDK_INT}}"""
    }

    private fun buildSplash(): RelativeLayout {
        val layout = RelativeLayout(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            layoutParams = FrameLayout.LayoutParams(-1, -1)
        }
        val titleId = View.generateViewId()
        val title = TextView(this).apply {
            text = "PULSE"
            textSize = 44f
            setTextColor(android.graphics.Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            letterSpacing = 0.15f
            id = titleId
            layoutParams = RelativeLayout.LayoutParams(-2, -2).also {
                it.addRule(RelativeLayout.CENTER_HORIZONTAL)
                it.addRule(RelativeLayout.CENTER_VERTICAL)
                it.topMargin = -resources.displayMetrics.density.toInt() * 40
            }
        }
        val sub = TextView(this).apply {
            text = "Free Music · by Harsh"
            textSize = 13f
            setTextColor(android.graphics.Color.parseColor("#b3b3b3"))
            layoutParams = RelativeLayout.LayoutParams(-2, -2).also {
                it.addRule(RelativeLayout.CENTER_HORIZONTAL)
                it.addRule(RelativeLayout.BELOW, titleId)
                it.topMargin = (resources.displayMetrics.density * 10).toInt()
            }
        }
        val pb = ProgressBar(this, null, android.R.attr.progressBarStyle).apply {
            indeterminateTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#1db954"))
            val dp = (resources.displayMetrics.density * 48).toInt()
            layoutParams = RelativeLayout.LayoutParams(dp, dp).also {
                it.addRule(RelativeLayout.CENTER_HORIZONTAL)
                it.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM)
                it.bottomMargin = (resources.displayMetrics.density * 80).toInt()
            }
        }
        layout.addView(title); layout.addView(sub); layout.addView(pb)
        return layout
    }

    override fun onResume() { super.onResume(); webView.onResume() }
    override fun onPause() { super.onPause(); webView.onPause() }
    override fun onDestroy() {
        if (wakeLock.isHeld) wakeLock.release()
        webView.destroy()
        super.onDestroy()
    }
}
