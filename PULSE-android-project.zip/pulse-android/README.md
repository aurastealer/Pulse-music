# PULSE Music — by Harsh
Free worldwide music streaming. 600,000+ tracks. No login. No ads.

## Get the APK in 6 steps — no Android Studio needed

**Step 1** → Go to github.com and create a free account

**Step 2** → Click + → New repository → name it `pulse-music` → Public → Create

**Step 3** → On the new repo page click "uploading an existing file" → drag ALL these files in (including the .github folder) → Commit changes

**Step 4** → Click the **Actions** tab → watch "Build PULSE APK" run (3–5 minutes)

**Step 5** → Click the finished run → scroll to Artifacts → click **PULSE-Music-APK** to download

**Step 6** → Transfer APK to your phone → open it → allow unknown sources when prompted → Install → done

---
Built by **Harsh** · Jamendo API · PULSE v1.0
